<?php
include "vulnerability.php";
?>

<label> text :</label>
<input type="text">
<input type="submit" name="state" value="INPUT_FROM_USER">